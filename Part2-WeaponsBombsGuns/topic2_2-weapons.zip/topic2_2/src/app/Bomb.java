package app;

public class Bomb extends Weapon {

    @Override
    public void fireWeapon(int power) {
        System.out.println("Bomb fired with power: " + power);
    }

    // Overloaded method (no arguments)
    public void fireWeapon() {
        System.out.println("Bomb fired (no power given)");
        super.fireWeapon(5); // Default power value
    }

    @Override
    public void activate(boolean enable) {
        System.out.println("Bomb activated: " + enable);
    }
}
