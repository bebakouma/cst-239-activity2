package app;

public abstract class Weapon {
    public void fireWeapon(int power) {
        System.out.println(getClass().getSimpleName() + " fires with power: " + power);
    }

    public abstract void activate(boolean enable);
}
