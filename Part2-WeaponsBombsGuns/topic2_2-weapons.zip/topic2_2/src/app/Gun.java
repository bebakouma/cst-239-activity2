package app;

public class Gun extends Weapon {

    @Override
    public void fireWeapon(int power) {
        System.out.println("Gun fired with power: " + power);
    }

    // Overloaded method (no arguments)
    public void fireWeapon() {
        System.out.println("Gun fired (no power given)");
        super.fireWeapon(3); // Default power value
    }

    @Override
    public void activate(boolean enable) {
        System.out.println("Gun activated: " + enable);
    }
}
