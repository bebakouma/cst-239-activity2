package app;

import java.util.Random;

public class Batman extends SuperHero {
    public Batman() {
        super("Batman", new Random().nextInt(1000) + 1);
    }
}
