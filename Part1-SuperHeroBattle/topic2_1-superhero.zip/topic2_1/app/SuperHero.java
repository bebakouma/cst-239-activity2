package app;

import java.util.Random;

public class SuperHero {
    private String name;
    private int health;
    private boolean isDead;

    public SuperHero(String name, int health) {
        this.name = name;
        this.health = health;
        this.isDead = false;
    }

    public void attack(SuperHero opponent) {
        Random rand = new Random();
        int damage = rand.nextInt(10) + 1;
        System.out.println(this.name + " attacks " + opponent.name + " for " + damage + " damage.");
        opponent.determineHealth(damage);
        System.out.println(opponent.name + " health is now: " + opponent.health);
    }

    public boolean isDead() {
        return isDead;
    }

    private void determineHealth(int damage) {
        this.health -= damage;
        if (this.health <= 0) {
            this.health = 0;
            this.isDead = true;
            System.out.println(this.name + " is now dead.");
        }
    }
}
