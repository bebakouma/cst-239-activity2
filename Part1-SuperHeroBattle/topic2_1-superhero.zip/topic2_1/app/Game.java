package app;

public class Game {
    public static void main(String[] args) {
        Superman superman = new Superman();
        Batman batman = new Batman();

        System.out.println("Battle Begins!\n");

        while (!superman.isDead() && !batman.isDead()) {
            superman.attack(batman);
            if (batman.isDead()) break;

            batman.attack(superman);
            if (superman.isDead()) break;

            System.out.println("-------------------");
        }

        System.out.println("\nBattle Over!");
        if (superman.isDead()) {
            System.out.println("🏴 Superman lost!");
        } else {
            System.out.println("🏴 Batman lost!");
        }
    }
}
