package app;

import java.util.Random;

public class Superman extends SuperHero {
    public Superman() {
        super("Superman", new Random().nextInt(1000) + 1);
    }
}
