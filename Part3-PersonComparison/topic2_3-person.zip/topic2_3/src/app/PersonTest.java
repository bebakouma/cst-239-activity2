package app;

public class PersonTest {
    public static void main(String[] args) {
        Person p1 = new Person("Alice", 30);
        Person p2 = new Person("Bob", 25);
        Person p3 = new Person("Alice", 30);

        System.out.println("p1: " + p1);
        System.out.println("p2: " + p2);
        System.out.println("p3: " + p3);

        System.out.println("\np1 == p2? " + p1.equals(p2));
        System.out.println("p1 == p3? " + p1.equals(p3));
    }
}
